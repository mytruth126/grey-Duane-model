Data=Input();
X=Data(:,2);Y=Data(:,1);
thetac=X./Y;
lnt=log(X);
lnt_n=log(X./Y);
lnn_t=log(Y./X);
Y1=cumsum([X(1);X(2:end,1)-X(1:end-1,1)].*Y);
Y1_X=Y1./X;
cftool
n=numel(X);
time_interval=[X(1);X(2:end)-X(1:end-1)];
D=zeros(n,n);
for i=1:n
    for j=1:i
        D(i,j)=1;
    end
end
Y2=D*(Y.*time_interval);
[fitresult, gof] = createFit(X, Y)
YF_GDM=fitresult(Y1_X)
subplot(3,2,1)
h = plot( fitresult, X, Y );