clear;clc;warning off;
global nf Data
nf=2;
[Data]=Input();
n=size(Data,1)-nf;
[error,X0,X0F1,theta1,p1]= grey_duane17();
[error,X0,X0F2,theta2,p2]= Duane();
[error,N0,X0F3,theta3,p3]= DM();
nf2=5;
tf_1=(([Data(:,1);Data(end,1)+[1:nf2]']-p1(3))/p1(1)).^(1/p1(2));
tf_2=([Data(:,1);Data(end,1)+[1:nf2]']/p2(1)).^(1/(1-p2(2)));
tf_3=((p3(2)*([Data(:,1);Data(end,1)+[1:nf2]'])+(p3(2)^2*([Data(:,1);Data(end,1)+[1:nf2]']).^2+4*p3(1)*([Data(:,1);Data(end,1)+[1:nf2]'])).^0.5)/2).^2;
Result=[X0F1,theta1,tf_1(1:end-nf2,1),X0F2,theta2,tf_2(1:end-nf2,1),X0F3,theta3,tf_3(1:end-nf2,1)];
Result2=[X0F2,tf_2(1:end-nf2,1),X0F3,tf_3(1:end-nf2,1),X0F1,tf_1(1:end-nf2,1),theta2,theta3,theta1];
p=[p1,p2,0,p3];
Result3=cell(size(Result2,1)+1,size(Result2,2));
Result3(1,:)=[{'Duane_Nt'},{'Duane_t'},{'DM_Nt'},{'DM_t'},{'GDM_Nt'},{'GDM_t'},{'Duane_MTBF'},{'DM_MTBF'},{'GDM_MTBF'}];
Result3(2:end,:)=num2cell(Result2);





