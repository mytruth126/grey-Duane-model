function [error,X0,X0F,theta,p]= grey_duane17()
global nf Data
tk=Data(1:end-nf,2);
time_interval=[tk(1);tk(2:end)-tk(1:end-1)];
X0=Data(1:end-nf,1);
n=numel(tk);
for i=1:n+nf
    for j=1:i
        D(i,j)=1;
    end
end
XR=D(1:n,1:n)*(X0.*time_interval);
% ��С���˷�
B=ones(n-1,2);
Y=ones(n-1,1);
B(:,1)=(XR(2:end,1)./tk(2:end,1)+XR(1:end-1,1)./tk(1:end-1,1))/2.*(tk(2:end)-tk(1:end-1));
B(:,2)=(tk(2:end)-tk(1:end-1));
Y(:,1)=(XR(2:n,:)-XR(1:n-1,:));
P=inv(B'*B)*B'*Y;
% ������
b=P(1)-1;
B1=ones(n,2);
B1(:,1)=tk.^b;
Y1=X0;
P1=inv(B1'*B1)*B1'*Y1;
a=P1(1);c=P1(2);
p=[a,1-b,c];
tk=Data(1:end,2);time_interval=[tk(1);tk(2:end)-tk(1:end-1)];
X0F=a*tk.^(b)+c;
error=mean(abs(X0(1:n,:)-X0F(1:n,:)).^2);
theta_c1=tk./X0F;
theta_c2=tk./(a*tk.^(1-b)+c);
theta=tk.^(1-b)/(a*(1-b));
end