function [error,X0,X0F,theta,p2]= Duane()
global nf Data
tk=Data(1:end-nf,2);
time_interval=[tk(1);tk(2:end)-tk(1:end-1)];
X0=Data(1:end-nf,1);
n=numel(X0);
thetack=tk./X0;
Lxx=sum(log(tk).^2)-(sum(log(tk))).^2/numel(tk);
Lyy=sum(log(thetack).^2)-(sum(log(thetack))).^2/numel(thetack);
Lxy=sum(log(tk).*log(thetack))-sum(log(tk))*sum(log(thetack))/numel(thetack);
m=Lxy/Lxx;
a=exp(1/numel(thetack)*(m*sum(log(tk))-sum(log(thetack))));
p=Lxy/(Lxx.^0.5*Lyy.^0.5);%���ϵ��
tk=Data(:,2);
theta=tk.^m/(a*(1-m));
X0F=a*tk.^(1-m);
error=mean(abs(X0(1:n,:)-X0F(1:n,:)).^2);
mape=mean(abs(X0(1:n,:)-X0F(1:n,:))./X0(1:n,:));
p2=[a,m];

end
