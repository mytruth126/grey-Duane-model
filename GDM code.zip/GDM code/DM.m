function [error,N0,N0F,theta,p2]= DM()
% A new reliability growth model: its mathematical comparison to the Duane model
%MTBF thetac=a+b*t^0.5
global nf Data
tk=Data(1:end-nf,2);n=numel(tk);
time_interval=[tk(1);tk(2:end)-tk(1:end-1)];
N0=Data(1:end-nf,1);
Y=tk./N0;
B=ones(n,2);
B(:,2)=tk.^0.5;
P=inv(B'*B)*B'*Y;
a=P(1);b=P(2);
tk=Data(1:end,2);
theta=(a+b*tk.^0.5).^2./(0.5*(2*a+b*tk.^0.5));
N0F=tk./(a+b*tk.^0.5);
error=mean(abs(N0(1:n,:)-N0F(1:n,:)).^2);
mape=mean(abs(N0(1:n,:)-N0F(1:n,:))./N0(1:n,:));
p2=[a,b];
end
